/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hyperlink;

import java.awt.Desktop;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import javax.swing.JLabel;
/**
 *
 * @author Yessi
 */
public class NewClass extends JLabel{
    
    private String pagina="";
    private boolean entrar;   
    
    public NewClass(){
        addMouseListener(new MouseAdapter() {
            
            @Override
            public void mousePressed(MouseEvent e) {
                abrirPagina();

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                entrar = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                entrar = false;
                repaint();
            }

            
            
        });
    }
    
    private void abrirPagina() {
        try {
            Desktop.getDesktop().browse(new URI(pagina));
        } catch (Exception e) {
        }
    }

    @Override
    public void paint(Graphics g) {
        Graphics2D gd= (Graphics2D) g;
        
        if (entrar) {
            gd.rotate(Math.toRadians(30), getWidth()/2, getHeight()/2);
        }
        
        super.paint(gd);
    }

    public String getPagina() {
        return pagina;
    }

    public void setPagina(String pagina) {
        this.pagina = pagina;
    } 
}
