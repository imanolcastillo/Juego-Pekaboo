
/*Parte de los códigos que se utilizaron para la realizacion de esta actividad se encuentras ubicados en:
https://docs.oracle.com/javase/7/docs/api/
 */
package Ventanas;

//Importar Audios
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import prueba.prueba;


public class Interfaz extends javax.swing.JFrame {

    //Detectar Audios
    public Clip clip;
    public String ruta = "/Audios/";

    //Ventana quede ubicada en el centro de la panatalla
    public Interfaz() {
        initComponents();
        this.setLocationRelativeTo(null);
        setResizable(false);
    }

    //Buscar Sonidos en el paquete
    public void sonido(String archivo) {
        try {
            clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(getClass().getResourceAsStream(ruta + archivo + ".wav")));
            clip.start();

        } catch (IOException | LineUnavailableException | UnsupportedAudioFileException e) {
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Sources = new javax.swing.JButton();
        Start = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        Titulo = new javax.swing.JLabel();
        Logo = new javax.swing.JLabel();
        jLabelFondo = new javax.swing.JLabel();

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo pw.jpg"))); // NOI18N
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconImage(getIconImage());
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Sources.setBackground(new java.awt.Color(204, 204, 255));
        Sources.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        Sources.setText("SOURCES");
        Sources.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Sources.setMaximumSize(new java.awt.Dimension(151, 61));
        Sources.setMinimumSize(new java.awt.Dimension(151, 61));
        Sources.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SourcesActionPerformed(evt);
            }
        });
        getContentPane().add(Sources, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 380, 240, 80));

        Start.setBackground(new java.awt.Color(204, 204, 255));
        Start.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        Start.setText("START");
        Start.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StartActionPerformed(evt);
            }
        });
        getContentPane().add(Start, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 240, 80));

        Exit.setBackground(new java.awt.Color(204, 204, 255));
        Exit.setFont(new java.awt.Font("Courier New", 1, 48)); // NOI18N
        Exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/equis.png"))); // NOI18N
        Exit.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Exit.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        getContentPane().add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, 70, 70));

        Titulo.setFont(new java.awt.Font("MV Boli", 2, 60)); // NOI18N
        Titulo.setText("PEEK-A-BOO");
        Titulo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Titulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TituloMouseClicked(evt);
            }
        });
        getContentPane().add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 440, -1));

        Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FotoJet3.jpg"))); // NOI18N
        Logo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoMouseClicked(evt);
            }
        });
        getContentPane().add(Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, -1, -1));

        jLabelFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo pw.jpg"))); // NOI18N
        jLabelFondo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.lightGray, java.awt.Color.lightGray));
        getContentPane().add(jLabelFondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 644, 497));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //BOTON DE SALIR 
    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        System.exit(0);
        sonido("Mouse Click");
    }//GEN-LAST:event_ExitActionPerformed

    //Botón de Inciar 
    private void StartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StartActionPerformed
        sonido("Kids Saying Yay");
        Cartas abrir = new Cartas();
        abrir.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_StartActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        sonido("peek-a-boo");
    }//GEN-LAST:event_jButton1MouseClicked

    private void LogoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoMouseClicked
        sonido("Music Box");
    }//GEN-LAST:event_LogoMouseClicked

    private void SourcesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SourcesActionPerformed
        // TODO add your handling code here:
        prueba ven =  new prueba();
        ven.setVisible(true);
    }//GEN-LAST:event_SourcesActionPerformed

    private void TituloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TituloMouseClicked
        // TODO add your handling code here:
        sonido("peek-a-boo");
    }//GEN-LAST:event_TituloMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Exit;
    private javax.swing.JLabel Logo;
    private javax.swing.JButton Sources;
    private javax.swing.JButton Start;
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabelFondo;
    // End of variables declaration//GEN-END:variables

}
